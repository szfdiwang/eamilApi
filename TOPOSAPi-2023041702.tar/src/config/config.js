/** 服务器部署环境 */
exports.env = process.env.NODE_ENV;

exports.serviceEmail = `shenminwen@matrixelements.com`